import { useState, useEffect, useRef } from 'react';
import { ExoplanetScene } from '@/components/ExoplanetScene';
import { DataUploadPanel } from '@/components/DataUploadPanel';
import { PlanetInfoPanel } from '@/components/PlanetInfoPanel';
import { TimeControls } from '@/components/TimeControls';
import { fetchNASAExoplanets, parseUserData, type Exoplanet } from '@/lib/exoplanetData';
import { Loader2 } from 'lucide-react';
const Index = () => {
  const [exoplanets, setExoplanets] = useState<Exoplanet[]>([]);
  const [focusedPlanet, setFocusedPlanet] = useState<Exoplanet | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeScale, setTimeScale] = useState(1);
  const [isPaused, setIsPaused] = useState(false);
  const [simulatedTime, setSimulatedTime] = useState(new Date());
  const lastUpdateRef = useRef(Date.now());
  useEffect(() => {
    const loadRealExoplanets = async () => {
      try {
        const realPlanets = await fetchNASAExoplanets();
        setExoplanets(realPlanets);
      } catch (error) {
        console.error('Error loading exoplanets:', error);
      } finally {
        setLoading(false);
      }
    };
    loadRealExoplanets();
  }, []);

  // Update simulated time based on timeScale
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isPaused) {
        const now = Date.now();
        const deltaMs = now - lastUpdateRef.current;
        lastUpdateRef.current = now;
        
        // timeScale represents days per second
        // Convert to milliseconds: timeScale days * 24 hours * 60 min * 60 sec * 1000 ms
        const simulatedDeltaMs = deltaMs * timeScale * 86400000 / 1000;
        
        setSimulatedTime(prevTime => new Date(prevTime.getTime() + simulatedDeltaMs));
      } else {
        lastUpdateRef.current = Date.now();
      }
    }, 100);
    
    return () => clearInterval(interval);
  }, [timeScale, isPaused]);
  const handleDataUpload = (csvData: string) => {
    try {
      const hypotheticalPlanets = parseUserData(csvData, 'csv', exoplanets.length);
      setExoplanets(prev => [...prev, ...hypotheticalPlanets]);
    } catch (error) {
      console.error('Error parsing data:', error);
    }
  };
  const handlePlanetClick = (planet: Exoplanet) => {
    setFocusedPlanet(planet);
  };
  const handleCloseInfo = () => {
    setFocusedPlanet(null);
  };
  const handleTogglePause = () => {
    setIsPaused(prev => !prev);
  };
  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
          <p className="text-muted-foreground">Loading NASA Exoplanet Data...</p>
        </div>
      </div>;
  }
  return <div className="relative w-full h-screen overflow-hidden">
      {/* 3D Scene */}
      <ExoplanetScene exoplanets={exoplanets} onPlanetClick={handlePlanetClick} focusedPlanet={focusedPlanet} timeScale={timeScale} isPaused={isPaused} />

      {/* Data Upload Panel - Bottom Right */}
      <div className="fixed bottom-20 right-6 z-10">
        <DataUploadPanel onDataUploaded={handleDataUpload} />
      </div>

      {/* Time Controls - Bottom Center */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-10">
        <TimeControls 
          timeScale={timeScale} 
          isPaused={isPaused} 
          onTimeScaleChange={setTimeScale} 
          onTogglePause={handleTogglePause}
          simulatedTime={simulatedTime}
        />
      </div>

{/* Planet Info Panel */}
      <PlanetInfoPanel planet={focusedPlanet} onClose={handleCloseInfo} />

      {/* Legend */}
      <div className="fixed bottom-6 left-6 bg-gradient-panel backdrop-blur-md border border-border rounded-lg shadow-panel p-4 space-y-2">
        <h3 className="text-sm font-semibold text-foreground mb-3">Legend</h3>
        
        <div className="flex items-center gap-2 text-xs">
          <div className="w-8 h-0.5 bg-real-orbit" />
          <span className="text-muted-foreground">Real Orbits</span>
        </div>
        
        <div className="flex items-center gap-2 text-xs">
          <div className="w-8 h-0.5 bg-hypothetical-orbit" />
          <span className="text-muted-foreground">Hypothetical Orbits</span>
        </div>
        <div className="pt-2 mt-2 border-t border-border">
          <p className="text-xs text-muted-foreground">
            Click any planet to view details
          </p>
        </div>
      </div>

      {/* Title */}
      <div className="fixed top-6 left-6 z-10">
        <div className="space-y-1">
          <h1 className="text-foreground font-extralight text-4xl">Moon Theif</h1>
          <p className="text-sm text-muted-foreground">
            AI-Powered 3D Simulation • {exoplanets.filter(p => p.isReal).length} Real • {exoplanets.filter(p => !p.isReal).length} Hypothetical
          </p>
        </div>
      </div>
    </div>;
};
export default Index;