import { Pause, Play, FastForward, Rewind } from 'lucide-react';
import { Button } from './ui/button';

interface TimeControlsProps {
  timeScale: number;
  isPaused: boolean;
  onTimeScaleChange: (scale: number) => void;
  onTogglePause: () => void;
  simulatedTime: Date;
}

export const TimeControls = ({ timeScale, isPaused, onTimeScaleChange, onTogglePause, simulatedTime }: TimeControlsProps) => {
  
  const formatDate = (date: Date) => {
    return date.toISOString().split('T')[0];
  };
  
  const formatUTC = (date: Date) => {
    return date.toISOString().split('T')[1].split('.')[0];
  };
  
  return (
    <div className="flex flex-col items-center gap-2">
      {/* Time Display */}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span>Date: {formatDate(simulatedTime)}</span>
        <span>UTC: {formatUTC(simulatedTime)}</span>
        <span>Speed: {timeScale} day/s</span>
      </div>
      
      {/* Controls */}
      <div className="bg-gradient-panel backdrop-blur-md border border-border rounded-lg shadow-panel p-4">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => onTimeScaleChange(Math.max(0.25, timeScale / 2))}
            className="h-8 w-8"
          >
            <Rewind className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={onTogglePause}
            className="h-8 w-8"
          >
            {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onTimeScaleChange(Math.min(8, timeScale * 2))}
            className="h-8 w-8"
          >
            <FastForward className="h-4 w-4" />
          </Button>
          <span className="text-xs text-muted-foreground ml-2 min-w-[40px]">
            {timeScale}x
          </span>
        </div>
      </div>
    </div>
  );
};
