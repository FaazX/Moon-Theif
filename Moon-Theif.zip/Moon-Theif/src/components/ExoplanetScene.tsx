import { useRef, useMemo, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Stars, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import type { Exoplanet } from '@/lib/exoplanetData';
import { calculateOrbitalPosition, generateOrbitPath } from '@/lib/orbitalMechanics';
import nebulaBackground from '@/assets/nebula-background.jpg';
import sunAnimatedTexture from '@/assets/textures/sun-animated.jpg';
import planetBlueCold from '@/assets/textures/planet-blue-cold.jpg';
import planetOrangeWarm from '@/assets/textures/planet-orange-warm.jpg';
import planetRedHot from '@/assets/textures/planet-red-hot.jpg';
import planetRedTexture from '@/assets/textures/planet-red-texture.jpg';
import planetYellowTexture from '@/assets/textures/planet-yellow-texture.jpg';

interface Planet3DProps {
  exoplanet: Exoplanet;
  onPlanetClick: (planet: Exoplanet) => void;
  onRequestFocus: (planet: Exoplanet, position: THREE.Vector3) => void;
  focusedPlanet: Exoplanet | null;
  timeScale: number;
  isPaused: boolean;
}

interface Planet3DPropsInternal extends Planet3DProps {
  registerMesh: (id: string, mesh: THREE.Mesh | null) => void;
}

const Planet3D = ({ exoplanet, onPlanetClick, onRequestFocus, focusedPlanet, timeScale, isPaused, registerMesh }: Planet3DPropsInternal) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const blueColdTexture = useTexture(planetBlueCold);
  const orangeWarmTexture = useTexture(planetOrangeWarm);
  const redHotTexture = useTexture(planetRedHot);
  const redTexture = useTexture(planetRedTexture);
  const yellowTexture = useTexture(planetYellowTexture);
  
  const startOffset = useMemo(() => Math.random() * Math.PI * 2, [exoplanet.id]);
  const textureVariant = useMemo(() => Math.floor(Math.random() * 2), [exoplanet.id]);
  
  // Register mesh for camera tracking
  useEffect(() => {
    if (meshRef.current) {
      registerMesh(exoplanet.id, meshRef.current);
    }
    return () => registerMesh(exoplanet.id, null);
  }, [exoplanet.id, registerMesh]);

useFrame(({ clock }) => {
  if (!meshRef.current || isPaused) return;

  const time = clock.getElapsedTime() * 10 * timeScale;
  const position = calculateOrbitalPosition(
    {
      semiMajorAxis: exoplanet.semiMajorAxis,
      eccentricity: exoplanet.eccentricity,
      orbitalPeriod: exoplanet.orbitalPeriod,
      inclination: exoplanet.inclination,
    },
    time,
    startOffset
  );

  meshRef.current.position.copy(position);
  // Simple axial rotation for realism
  meshRef.current.rotation.y += 0.01;
});

  const planetRadius = Math.max(0.05, exoplanet.radius * 0.03);
  const isFocused = focusedPlanet?.id === exoplanet.id;
  
  const getPlanetTexture = () => {
    if (exoplanet.temperature < 240) {
      return blueColdTexture;
    }
    if (exoplanet.temperature < 270) {
      return textureVariant === 0 ? orangeWarmTexture : yellowTexture;
    }
    return textureVariant === 0 ? redHotTexture : redTexture;
  };
  
  const getEmissiveColor = () => {
    if (exoplanet.temperature < 240) return '#4a9eff';
    if (exoplanet.temperature < 270) return '#ff8c42';
    return '#ff4757';
  };

  return (
    <mesh
      ref={meshRef}
onClick={(e) => {
        e.stopPropagation();
        onPlanetClick(exoplanet);
      }}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      scale={hovered || isFocused ? 1.5 : 1}
    >
      <sphereGeometry args={[planetRadius, 64, 64]} />
      <meshStandardMaterial
        map={getPlanetTexture()}
        emissive={getEmissiveColor()}
        emissiveIntensity={hovered || isFocused ? 0.3 : 0.05}
        roughness={0.7}
        metalness={0.3}
        normalScale={new THREE.Vector2(0.5, 0.5)}
      />
      {(hovered || isFocused) && (
        <>
          <pointLight
            color={getEmissiveColor()}
            intensity={1.5}
            distance={planetRadius * 4}
          />
          <mesh scale={1.1}>
            <sphereGeometry args={[planetRadius, 32, 32]} />
            <meshBasicMaterial
              color={getEmissiveColor()}
              transparent
              opacity={0.1}
            />
          </mesh>
        </>
      )}
    </mesh>
  );
};

interface OrbitLineProps {
  exoplanet: Exoplanet;
}

const OrbitLine = ({ exoplanet }: OrbitLineProps) => {
  const orbitPath = useMemo(() => {
    return generateOrbitPath(
      {
        semiMajorAxis: exoplanet.semiMajorAxis,
        eccentricity: exoplanet.eccentricity,
        orbitalPeriod: exoplanet.orbitalPeriod,
        inclination: exoplanet.inclination,
      },
      256
    );
  }, [exoplanet]);

  const geometry = useMemo(() => {
    const geom = new THREE.BufferGeometry().setFromPoints(orbitPath);
    return geom;
  }, [orbitPath]);

  return (
    <primitive object={new THREE.Line(geometry, new THREE.LineBasicMaterial({
      color: exoplanet.isReal ? '#f1c40f' : '#ff0000',
      transparent: true,
      opacity: 0.4,
    }))} />
  );
};

interface ExoplanetSceneProps {
  exoplanets: Exoplanet[];
  onPlanetClick: (planet: Exoplanet) => void;
  focusedPlanet: Exoplanet | null;
  timeScale: number;
  isPaused: boolean;
  onCameraReset?: () => void;
}

const Sun = () => {
  const sunRef = useRef<THREE.Mesh>(null);
  const sunTextureMap = useTexture(sunAnimatedTexture);
  const sunMaterialRef = useRef<THREE.MeshStandardMaterial>(null);
  
  useFrame(({ clock }) => {
    if (sunRef.current) {
      sunRef.current.rotation.y += 0.002;
    }
    if (sunMaterialRef.current) {
      sunMaterialRef.current.emissiveIntensity = 1.8 + Math.sin(clock.getElapsedTime() * 2) * 0.3;
    }
  });
  
  return (
    <mesh ref={sunRef} position={[0, 0, 0]}>
      <sphereGeometry args={[0.3, 64, 64]} />
      <meshStandardMaterial
        ref={sunMaterialRef}
        map={sunTextureMap}
        emissive="#ffffff"
        emissiveIntensity={1.8}
        toneMapped={false}
      />
    </mesh>
  );
};

const Scene = ({ exoplanets, onPlanetClick, focusedPlanet, timeScale, isPaused, onCameraReset }: ExoplanetSceneProps) => {
  const controlsRef = useRef<any>(null);
  const { camera } = useThree();
  
  const planetMeshesRef = useRef<Map<string, THREE.Mesh>>(new Map());
  
  const registerPlanetMesh = (id: string, mesh: THREE.Mesh | null) => {
    if (mesh) {
      planetMeshesRef.current.set(id, mesh);
    }
  };

  useFrame(() => {
    if (!controlsRef.current) return;
    
    // Camera tracking for focused planet
    if (focusedPlanet) {
      const planetMesh = planetMeshesRef.current.get(focusedPlanet.id);
      if (planetMesh) {
        const planetPos = new THREE.Vector3();
        planetMesh.getWorldPosition(planetPos);
        
        // Smoothly move controls target to planet position
        controlsRef.current.target.lerp(planetPos, 0.1);
        
        // Calculate camera position offset from planet
        const planetRadius = Math.max(0.05, focusedPlanet.radius * 0.03);
        const cameraDistance = Math.max(planetRadius * 6, 1.0);
        
        // Get current camera direction
        const direction = new THREE.Vector3();
        camera.getWorldDirection(direction);
        direction.negate();
        direction.normalize();
        
        // Position camera at offset from planet
        const targetCameraPos = planetPos.clone().add(direction.multiplyScalar(cameraDistance));
        camera.position.lerp(targetCameraPos, 0.08);
        
        camera.lookAt(planetPos);
      }
    }
  });

  return (
    <>
      {/* Background */}
      <color attach="background" args={['#000000']} />
      
      {/* Ambient Light */}
      <ambientLight intensity={0.3} />
      
      {/* Sun with rotation */}
      <Sun />
      
      {/* Sun lighting - white/natural light */}
      <pointLight position={[0, 0, 0]} intensity={5} color="#ffffff" distance={30} decay={2} />

      {/* Stars */}
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />

      {/* Orbits */}
      {exoplanets.map((exoplanet) => (
        <OrbitLine key={`orbit-${exoplanet.id}`} exoplanet={exoplanet} />
      ))}

      {/* Planets */}
{exoplanets.map((exoplanet) => (
        <Planet3D
          key={exoplanet.id}
          exoplanet={exoplanet}
          onPlanetClick={onPlanetClick}
          onRequestFocus={(planet, pos) => {}}
          focusedPlanet={focusedPlanet}
          timeScale={timeScale}
          isPaused={isPaused}
          registerMesh={registerPlanetMesh}
        />
      ))}

{/* Camera Controls */}
      <OrbitControls
        ref={controlsRef}
        enableDamping
        dampingFactor={0.05}
        minDistance={0.3}
        maxDistance={20}
      />
    </>
  );
};

export const ExoplanetScene = ({ exoplanets, onPlanetClick, focusedPlanet, timeScale, isPaused, onCameraReset }: ExoplanetSceneProps) => {
  return (
    <div className="w-full h-screen relative" style={{
      backgroundImage: `url(${nebulaBackground})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    }}>
      <div className="absolute inset-0 bg-black/40" />
      <Canvas
        camera={{ fov: 60 }}
        className="absolute inset-0"
      >
        <Scene 
          exoplanets={exoplanets} 
          onPlanetClick={onPlanetClick} 
          focusedPlanet={focusedPlanet}
          timeScale={timeScale}
          isPaused={isPaused}
          onCameraReset={onCameraReset}
        />
      </Canvas>
    </div>
  );
};
