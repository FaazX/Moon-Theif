import { useState } from 'react';
import { Upload, FileJson, FileSpreadsheet, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';
import { presetData } from '@/lib/exoplanetData';
interface DataUploadPanelProps {
  onDataUploaded: (csvData: string) => void;
}
export const DataUploadPanel = ({
  onDataUploaded
}: DataUploadPanelProps) => {
  const [inputText, setInputText] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      const text = e.target?.result as string;
      setInputText(text);
      toast.success('File loaded successfully');
    };
    if (file.name.endsWith('.json')) {
      reader.readAsText(file);
    } else if (file.name.endsWith('.csv')) {
      reader.readAsText(file);
    } else {
      toast.error('Please upload a CSV or JSON file');
    }
  };
  const handleSubmit = () => {
    if (!inputText.trim()) {
      toast.error('Please enter or upload data first');
      return;
    }
    try {
      onDataUploaded(inputText);
      toast.success('Hypothetical exoplanets added to simulation');
      setIsExpanded(false);
    } catch (error) {
      toast.error('Error parsing data. Please check format.');
    }
  };
  const loadPreset = (presetKey: keyof typeof presetData, presetName: string) => {
    setInputText(presetData[presetKey]);
    toast.success(`${presetName} loaded - 5 exoplanets ready`);
  };
  const exampleCSV = `name,semimajoraxis,eccentricity,period,radius,temperature,inclination
HD-209b,1.2,0.15,150,1.1,270,88
Proxima-c,0.8,0.05,90,0.9,240,92
Custom-1,1.5,0.2,200,1.3,285,85`;
  return <div className="bg-gradient-panel backdrop-blur-md border border-border rounded-lg shadow-panel overflow-hidden w-96">
        {/* Header */}
        <div className="px-4 py-3 bg-card/50 border-b border-border cursor-pointer flex items-center justify-between" onClick={() => setIsExpanded(!isExpanded)}>
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-primary" />
            <span className="font-semibold text-foreground">Data Input</span>
          </div>
          <span className="text-xs text-muted-foreground">
            {isExpanded ? 'Click to collapse' : 'Click to expand'}
          </span>
        </div>

        {/* Content */}
        {isExpanded && <div className="p-4 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Upload Hypothetical Exoplanet Data
              </label>
              <p className="text-xs text-muted-foreground">
                CSV format with columns: name, semimajoraxis, eccentricity, period, radius, temperature, inclination
              </p>
            </div>

            {/* Preset Buttons */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground flex items-center gap-2">
                
                Quick Presets (5 planets each)
              </label>
              <div className="grid grid-cols-3 gap-2">
                <Button variant="outline" size="sm" onClick={() => loadPreset('preset1', 'Habitable Candidates')} className="text-xs">
                  Set 1
                </Button>
                <Button variant="outline" size="sm" onClick={() => loadPreset('preset2', 'Close Orbits')} className="text-xs">
                  Set 2
                </Button>
                <Button variant="outline" size="sm" onClick={() => loadPreset('preset3', 'Earth-Like')} className="text-xs">
                  Set 3
                </Button>
              </div>
            </div>

            {/* File Upload Buttons */}
            <div className="flex gap-2">
              <label className="flex-1">
                <input type="file" accept=".csv,.json" onChange={handleFileUpload} className="hidden" />
                <Button variant="outline" className="w-full" asChild>
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4" />
                    CSV File
                  </span>
                </Button>
              </label>
              <label className="flex-1">
                <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
                <Button variant="outline" className="w-full" asChild>
                  <span className="flex items-center gap-2">
                    <FileJson className="w-4 h-4" />
                    JSON File
                  </span>
                </Button>
              </label>
            </div>

            {/* Text Input */}
            <div className="space-y-2">
              <Textarea value={inputText} onChange={e => setInputText(e.target.value)} placeholder={`Paste CSV data here...\n\nExample:\n${exampleCSV}`} className="min-h-[200px] font-mono text-xs bg-background/50" />
            </div>

            {/* Submit Button */}
            <Button onClick={handleSubmit} className="w-full" disabled={!inputText.trim()}>
              Add to Simulation
            </Button>

            {/* Help Text */}
            
          </div>}
    </div>;
};