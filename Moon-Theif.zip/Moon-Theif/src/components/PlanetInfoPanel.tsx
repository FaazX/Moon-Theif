import { X, Globe, Orbit, Thermometer, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import type { Exoplanet } from '@/lib/exoplanetData';

interface PlanetInfoPanelProps {
  planet: Exoplanet | null;
  onClose: () => void;
}

export const PlanetInfoPanel = ({ planet, onClose }: PlanetInfoPanelProps) => {
  if (!planet) return null;
  
  const orbitData = [
    { name: 'Semi-Major Axis', value: planet.semiMajorAxis.toFixed(3), unit: 'AU' },
    { name: 'Eccentricity', value: planet.eccentricity.toFixed(3), unit: '' },
    { name: 'Period', value: planet.orbitalPeriod.toFixed(1), unit: 'days' },
    { name: 'Inclination', value: planet.inclination.toFixed(2), unit: '°' },
  ];
  
  const comparisonData = [
    { property: 'Radius', value: planet.radius, earth: 1 },
    { property: 'Temp', value: planet.temperature / 288, earth: 1 },
  ];

  const formatNumber = (num: number, decimals: number = 2) => {
    return num.toFixed(decimals);
  };

  return (
    <div className="fixed left-6 top-1/2 -translate-y-1/2 z-20 w-80 animate-in slide-in-from-left">
      <div className="bg-gradient-panel backdrop-blur-md border border-border rounded-lg shadow-panel overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 bg-card/50 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${planet.isReal ? 'bg-real-planet shadow-red-glow' : 'bg-hypothetical-planet shadow-gold-glow'}`} />
            <span className="font-semibold text-foreground">{planet.name}</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Classification */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Classification</span>
              <span className="text-sm font-medium text-foreground">
                {planet.isReal ? 'Real (NASA Data)' : 'Hypothetical (User Data)'}
              </span>
            </div>
            {planet.confidence && (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    AI Confidence
                  </span>
                  <span className="font-mono text-foreground">
                    {(planet.confidence * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-1.5">
                  <div 
                    className={`h-full rounded-full transition-all ${
                      planet.isReal ? 'bg-real-planet' : 'bg-hypothetical-planet'
                    }`}
                    style={{ width: `${planet.confidence * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Physical Properties */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <Globe className="w-4 h-4 text-primary" />
              Physical Properties
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <span className="text-muted-foreground">Radius</span>
                <p className="font-mono text-foreground">{formatNumber(planet.radius)} R⊕</p>
              </div>
              <div className="space-y-1">
                <span className="text-muted-foreground">Temperature</span>
                <p className="font-mono text-foreground flex items-center gap-1">
                  <Thermometer className="w-3 h-3" />
                  {formatNumber(planet.temperature)} K
                </p>
              </div>
            </div>
          </div>

          {/* Orbital Properties */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <Orbit className="w-4 h-4 text-primary" />
              Orbital Properties
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <span className="text-muted-foreground">Semi-Major Axis</span>
                <p className="font-mono text-foreground">{formatNumber(planet.semiMajorAxis)} AU</p>
              </div>
              <div className="space-y-1">
                <span className="text-muted-foreground">Period</span>
                <p className="font-mono text-foreground">{formatNumber(planet.orbitalPeriod)} days</p>
              </div>
              <div className="space-y-1">
                <span className="text-muted-foreground">Eccentricity</span>
                <p className="font-mono text-foreground">{formatNumber(planet.eccentricity, 3)}</p>
              </div>
              <div className="space-y-1">
                <span className="text-muted-foreground">Inclination</span>
                <p className="font-mono text-foreground">{formatNumber(planet.inclination)}°</p>
              </div>
            </div>
          </div>

          {/* Orbital Trend Graph */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-foreground">Orbital Parameters</h3>
            <div className="h-32 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={orbitData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                    angle={-15}
                    textAnchor="end"
                    height={40}
                  />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '12px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke={planet.isReal ? '#f1c40f' : '#ff0000'}
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Comparison Bar Chart */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-foreground">Earth Comparison</h3>
            <div className="h-32 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="property" 
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '12px'
                    }}
                  />
                  <Legend 
                    wrapperStyle={{ fontSize: '10px' }}
                    iconSize={10}
                  />
                  <Bar dataKey="value" fill={planet.isReal ? '#f1c40f' : '#ff0000'} name="This Planet" />
                  <Bar dataKey="earth" fill="#4a9eff" name="Earth" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AI Notes */}
          {!planet.isReal && (
            <div className="p-3 bg-muted/50 rounded-md border border-border">
              <p className="text-xs text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">AI Analysis:</span> This candidate was identified from user-provided data. The confidence score reflects the model's certainty based on known exoplanet characteristics.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
