import * as THREE from 'three';

export interface OrbitalElements {
  semiMajorAxis: number;
  eccentricity: number;
  orbitalPeriod: number;
  inclination: number;
}

/**
 * Calculate position on elliptical orbit using Kepler's laws
 * Returns position in 3D space
 */
export const calculateOrbitalPosition = (
  elements: OrbitalElements,
  time: number,
  startOffset: number = 0
): THREE.Vector3 => {
  const { semiMajorAxis, eccentricity, orbitalPeriod, inclination } = elements;
  
  // Mean anomaly (angle based on time) with start offset
  const meanAnomaly = (2 * Math.PI * time) / orbitalPeriod + startOffset;
  
  // Solve Kepler's equation for eccentric anomaly (simplified Newton-Raphson)
  let eccentricAnomaly = meanAnomaly;
  for (let i = 0; i < 5; i++) {
    eccentricAnomaly = meanAnomaly + eccentricity * Math.sin(eccentricAnomaly);
  }
  
  // True anomaly
  const trueAnomaly = 2 * Math.atan2(
    Math.sqrt(1 + eccentricity) * Math.sin(eccentricAnomaly / 2),
    Math.sqrt(1 - eccentricity) * Math.cos(eccentricAnomaly / 2)
  );
  
  // Distance from focus (sun)
  const radius = semiMajorAxis * (1 - eccentricity * eccentricity) / (1 + eccentricity * Math.cos(trueAnomaly));
  
  // Position in orbital plane
  const x = radius * Math.cos(trueAnomaly);
  const y = radius * Math.sin(trueAnomaly);
  
  // Apply inclination to create 3D tilt
  const inclinationRad = (inclination * Math.PI) / 180;
  const z = y * Math.sin(inclinationRad);
  const yTilted = y * Math.cos(inclinationRad);
  
  return new THREE.Vector3(x, z, yTilted);
};

/**
 * Generate points for complete orbital path
 */
export const generateOrbitPath = (
  elements: OrbitalElements,
  segments: number = 128
): THREE.Vector3[] => {
  const points: THREE.Vector3[] = [];
  const period = elements.orbitalPeriod;
  
  for (let i = 0; i <= segments; i++) {
    const time = (i / segments) * period;
    points.push(calculateOrbitalPosition(elements, time));
  }
  
  return points;
};

/**
 * Calculate orbital velocity (for realistic speed variation)
 * Planets move faster when closer to the sun (Kepler's second law)
 */
export const calculateOrbitalVelocity = (
  semiMajorAxis: number,
  eccentricity: number,
  currentRadius: number
): number => {
  // Vis-viva equation
  const mu = 1; // Gravitational parameter (normalized)
  const a = semiMajorAxis;
  const r = currentRadius;
  
  return Math.sqrt(mu * (2 / r - 1 / a));
};
