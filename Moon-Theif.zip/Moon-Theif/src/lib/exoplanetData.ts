export interface Exoplanet {
  id: string;
  name: string;
  semiMajorAxis: number; // AU
  eccentricity: number;
  orbitalPeriod: number; // days
  radius: number; // Earth radii
  temperature: number; // Kelvin
  inclination: number; // degrees
  isReal: boolean;
  confidence?: number; // AI confidence score (0-1)
}

export const fetchNASAExoplanets = async (): Promise<Exoplanet[]> => {
  try {
    const url = 'https://exoplanetarchive.ipac.caltech.edu/cgi-bin/nstedAPI/nph-nstedAPI?table=cumulative&where=koi_prad<2%20and%20koi_teq>180%20and%20koi_teq<303%20and%20koi_disposition%20like%20%27CANDIDATE%27&format=json';
    
    const response = await fetch(url);
    const data = await response.json();
    
    return data.slice(0, 50).map((item: any, index: number) => ({
      id: `real-${index}`,
      name: item.kepoi_name || `KOI-${index}`,
      semiMajorAxis: (item.koi_sma || 0.5 + Math.random() * 1.5) * 1.5 + index * 0.15,
      eccentricity: item.koi_eccen || Math.random() * 0.3,
      orbitalPeriod: item.koi_period || 100 + Math.random() * 200,
      radius: item.koi_prad || 1,
      temperature: item.koi_teq || 250,
      inclination: (item.koi_incl || 85) + Math.random() * 10,
      isReal: true,
      confidence: 0.85 + Math.random() * 0.15,
    }));
  } catch (error) {
    console.error('Error fetching NASA data:', error);
    // Fallback to mock data
    return generateMockRealExoplanets();
  }
};

const generateMockRealExoplanets = (): Exoplanet[] => {
  return Array.from({ length: 50 }, (_, i) => ({
    id: `real-${i}`,
    name: `Kepler-${186 + i}b`,
    semiMajorAxis: 0.5 + i * 0.15 + Math.random() * 0.3,
    eccentricity: Math.random() * 0.4,
    orbitalPeriod: 50 + Math.random() * 300,
    radius: 0.8 + Math.random() * 1.5,
    temperature: 200 + Math.random() * 100,
    inclination: 85 + Math.random() * 10,
    isReal: true,
    confidence: 0.85 + Math.random() * 0.15,
  }));
};

export const parseUserData = (csvText: string, format: string = 'csv', existingPlanetsCount: number = 0): Exoplanet[] => {
  // Simple CSV parsing for exoplanet data
  const lines = csvText.trim().split('\n');
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  
  return lines.slice(1).map((line, index) => {
    const values = line.split(',').map(v => v.trim());
    const planet: any = {};
    
    headers.forEach((header, i) => {
      planet[header] = values[i];
    });
    
    const baseSemiMajorAxis = parseFloat(planet.semimajoraxis || planet.sma || '1');
    const adjustedSemiMajorAxis = baseSemiMajorAxis * 1.5 + (existingPlanetsCount + index) * 0.15;
    
    return {
      id: `hypo-${Date.now()}-${index}`,
      name: planet.name || `Candidate-${index}`,
      semiMajorAxis: adjustedSemiMajorAxis,
      eccentricity: parseFloat(planet.eccentricity || planet.ecc || '0.1'),
      orbitalPeriod: parseFloat(planet.period || '100'),
      radius: parseFloat(planet.radius || '1'),
      temperature: parseFloat(planet.temperature || planet.temp || '250'),
      inclination: parseFloat(planet.inclination || '90'),
      isReal: false,
      confidence: Math.random() * 0.5 + 0.3, // Lower confidence for hypothetical
    };
  });
};

export const presetData = {
  preset1: `name,semimajoraxis,eccentricity,period,radius,temperature,inclination
Kepler-442b,0.409,0.04,112.3,1.34,233,89.7
TRAPPIST-1e,0.029,0.01,6.1,0.92,246,89.86
K2-18b,0.143,0.04,33,2.6,265,89.56
Proxima-b,0.0485,0.35,11.2,1.3,234,90
TOI-700d,0.163,0.04,37.4,1.19,268,89.65`,
  preset2: `name,semimajoraxis,eccentricity,period,radius,temperature,inclination
GJ-667Cc,0.125,0.02,28.1,1.54,277,88.5
Kepler-62f,0.718,0.05,267.3,1.41,208,89.98
LHS-1140b,0.0875,0.03,24.7,1.43,230,89.76
Ross-128b,0.05,0.03,9.9,1.35,269,88.83
HD-40307g,0.6,0.07,197.8,1.75,227,89.12`,
  preset3: `name,semimajoraxis,eccentricity,period,radius,temperature,inclination
Kepler-452b,1.046,0.08,384.8,1.63,265,89.81
Kepler-1649c,0.0649,0.06,19.5,1.06,234,89.7
LP-890-9c,0.04,0.02,8.5,1.37,271,89.4
TOI-175b,0.165,0.05,41.4,1.29,255,88.96
Wolf-1061c,0.089,0.11,17.9,1.64,223,89.35`
};
